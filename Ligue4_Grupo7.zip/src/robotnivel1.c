#include <stdio.h>
#include <stdlib.h>
#include "robotnivel1.h" 

int robotnivel1(){
    
    int jogada = (rand() % 7) + 1; // randomizador

    return jogada;

    return 0;
}