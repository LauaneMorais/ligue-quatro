#ifndef DISPLAY_H
#define DISPLAY_H

void limparTela();
void imprimirTabuleiro(int matriz[6][7]);

#endif