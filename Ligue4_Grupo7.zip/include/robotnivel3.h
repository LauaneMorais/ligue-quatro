#ifndef ROBOTNIVEL3_H
#define ROBOTNIVEL3_H

int robotnivel3(int tabuleiro[6][7], int jogadorIA);

#endif