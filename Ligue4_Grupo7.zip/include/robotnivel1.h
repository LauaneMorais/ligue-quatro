#ifndef ROBOTNIVEL1_H
#define ROBOTNIVEL1_H

int robotnivel1();

//.

#endif