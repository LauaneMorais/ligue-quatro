#ifndef VITORIA_H
#define VITORIA_H

// Retorna 1 se alguem ganhou e 0 se ninguem ganhou!
int vitoria(int tabuleiro[6][7], int jogador);

#endif