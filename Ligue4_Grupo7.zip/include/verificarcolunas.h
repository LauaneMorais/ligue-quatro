#ifndef VERIFICARCOLUNAS_H
#define VERIFICARCOLUNAS_H

int verificarcolunas(int tabuleiro[6][7], int jogada, int jogador);

// .

#endif